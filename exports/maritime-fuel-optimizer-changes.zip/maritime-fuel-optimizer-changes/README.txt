Maritime Fuel Optimizer — implementation changes

This archive contains the complete source-file snapshot of the feature changes, plus a unified Git patch.

Baseline: 0c05d76
Snapshot: d5e82e9
Files included: 105

Contents:
- files/: full new/modified project files, preserving their workspace-relative paths
- changes.patch: binary-safe patch from the baseline to the snapshot
- MANIFEST.txt: list of included source files

The original uploaded prompt and input archive under .conversation/attached_assets are intentionally excluded; they are user-provided source material, not implementation changes. Build outputs, node_modules, and generated runtime files are also excluded.
